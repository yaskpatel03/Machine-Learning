### Custom definitions and classes if any ###

def predict_runs(input_test):
    prediction = 0
    ### Your Code Here ###
    return prediction
